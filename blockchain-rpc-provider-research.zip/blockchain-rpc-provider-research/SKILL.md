---
name: blockchain-rpc-provider-research
description: Systematic workflow for researching and validating blockchain RPC providers. Use when evaluating RPC providers for historical data collection, rate limits, archive access, compute unit costs, or timeline estimation for large-scale blockchain data backfills.
---

# Blockchain RPC Provider Research

## Overview

This skill provides a systematic, empirically-validated workflow for researching blockchain RPC providers before committing to large-scale data collection projects. Use when selecting an RPC provider for historical blockchain data backfill, evaluating rate limits, comparing free tier options, or estimating collection timelines.

**Key principle**: Never trust documented rate limits—always validate empirically with POC testing.

## Investigation Workflow

Follow this 5-step workflow to research and validate RPC providers:

### Step 1: Research Official Documentation

Research the provider's documented capabilities:

**Key questions to answer**:
- What are the documented rate limits? (RPS or compute units/credits)
- Is archive node access included in the free tier?
- How far back does historical data go? (genesis block or limited?)
- What is the pricing model? (RPS-based, compute units, API credits)
- Are there separate limits for archive vs standard requests?

**Where to search**:
- Provider pricing pages (e.g., alchemy.com/pricing, infura.io/pricing)
- Documentation for compute unit costs or API credit costs
- Archive node documentation
- Community comparisons (search: "alchemy vs infura vs quicknode comparison")

**Common providers to evaluate**:
- **Alchemy**: Compute unit (CU) based, 300M CU/month free tier
- **Infura**: RPS-based, 100K requests/day free tier (25K archive/day)
- **QuickNode**: API credits, 50M credits/month free tier (disputed)
- **LlamaRPC**: RPS-based, 50 RPS documented (burst limit)

**Output**: Document findings in comparison matrix (see `references/rpc-comparison-template.md`)

### Step 2: Calculate Theoretical Timeline

Calculate the theoretical timeline based on documented limits:

**For RPS-based providers** (Infura, LlamaRPC):
```
Timeline (seconds) = Total blocks ÷ RPS
Timeline (days) = Timeline (seconds) ÷ 86,400
```

**For compute unit providers** (Alchemy):
```
1. Find CU cost per method (e.g., eth_getBlockByNumber = 20 CU)
2. Calculate: Monthly requests = Monthly CU ÷ CU per request
3. Calculate: Daily requests = Monthly requests ÷ 30
4. Calculate: Sustainable RPS = Daily requests ÷ 86,400
5. Timeline (days) = Total blocks ÷ Sustainable RPS ÷ 86,400
```

**For API credit providers** (QuickNode):
```
Same as compute units (if credit cost per method is known)
```

**Use the calculator script**:
```bash
python scripts/calculate_timeline.py --blocks 13000000 --rps 5.79
python scripts/calculate_timeline.py --blocks 13000000 --cu-per-month 300000000 --cu-per-request 20
```

**Critical insight**: Documented "maximum RPS" is often a **burst limit**, not sustained rate.

### Step 3: Empirical Validation with POC Testing

**MOST CRITICAL STEP**: Validate rate limits empirically with actual RPC calls.

**Why necessary**: Documented limits are often misleading:
- 50 RPS documented → 1.37 RPS sustainable (LlamaRPC case study)
- Burst limits ≠ sustained limits
- Sliding window rate limiting causes throttling over time

**Testing approach**:

Use the `scripts/test_rpc_rate_limits.py` template to test multiple configurations:

1. **Test 1: Single block fetch** - Validate connectivity and schema
2. **Test 2: Parallel fetch (high workers)** - Test burst limits
3. **Test 3: Parallel fetch (low workers)** - Find parallel threshold
4. **Test 4: Sequential with documented limit** - Test documented RPS
5. **Test 5: Ultra-conservative sequential** - Find sustainable rate

**Rate limit testing pattern**:
```python
# Start aggressive, reduce until 100% success rate
test_configs = [
    {"workers": 10, "expected": "likely fail"},
    {"workers": 3, "expected": "may fail"},
    {"rps": 10, "expected": "may fail"},
    {"rps": 5, "expected": "may work"},
    {"rps": 2, "expected": "should work"},
]
```

**Success criteria**: 100% success rate over 50-100 blocks minimum

**Output**: Document actual sustainable rate (not burst rate)

### Step 4: Create Comparison Matrix

Build a comparison matrix with empirical findings:

| Provider       | Timeline | Cost  | Archive | Rate Model | Verdict     |
|----------------|----------|-------|---------|------------|-------------|
| Provider A     | X days   | $Y    | Status  | RPS/CU     | Recommended |
| Provider B     | X days   | $Y    | Status  | RPS/CU     | Fallback    |

**Include these metrics**:
- Timeline (empirically validated, not theoretical)
- Speedup vs baseline (e.g., "4.2x faster than LlamaRPC")
- Cost (free tier vs paid)
- Archive access (Full / Limited / None)
- Rate model complexity (Simple RPS vs Complex CU tracking)
- API key requirement (Yes/No)
- Recommendation (Use / Fallback / Reject)

**See template**: `references/rpc-comparison-template.md`

### Step 5: Document Findings and Make Recommendation

Create a comprehensive report documenting:

1. **Executive Summary** - Recommended provider with key finding (e.g., "4.2x faster")
2. **Detailed Analysis** - Each provider with pros/cons
3. **Comparison Matrix** - Side-by-side metrics
4. **Implementation Strategy** - Conservative rate limits, monitoring, fallback plan
5. **Next Steps** - Account creation, empirical POC, timeline updates

**Report structure**: See `references/validated-providers.md` for example (Alchemy vs LlamaRPC case study)

**Key decisions to document**:
- Primary provider choice
- Conservative rate limit (X% below sustainable for safety margin)
- Fallback provider if primary hits unexpected limits
- Monitoring strategy (track daily usage, alert thresholds)

## Rate Limiting Best Practices

When implementing the selected provider:

**Conservative rate targeting**:
- Use 80-90% of empirically validated sustainable rate
- Example: 5.79 RPS sustained → use 5.0 RPS (86% = 14% safety margin)
- Leaves room for retries, daily fluctuations, and unexpected spikes

**Monitoring requirements**:
- Track daily usage (RPS, CU, or credits consumed)
- Alert if approaching daily/monthly limits (e.g., >10M CU/day for 300M/month limit)
- Log failed requests for retry queue
- Monitor success rate (should stay >99%)

**Fallback strategy**:
- Always have a validated fallback provider
- Example: Primary = Alchemy (5.0 RPS), Fallback = LlamaRPC (1.37 RPS)
- Timeline extends but collection continues if primary fails

## Common Pitfalls to Avoid

1. **Trusting documented burst limits as sustained rates**
   - Always empirically validate over 50+ requests minimum
   - Look for degradation over time (sliding window rate limiting)

2. **Testing with too few blocks**
   - 10-20 blocks may succeed, then fail at block 50+ due to cumulative throttling
   - Test minimum 50 blocks, ideally 100+

3. **Parallel fetching on free tiers**
   - Even 3 workers can trigger rate limits on strict free tiers
   - Default to sequential with delays unless proven otherwise

4. **Ignoring compute unit costs per method**
   - eth_blockNumber (10 CU) ≠ eth_getBlockByNumber (20 CU)
   - Calculate based on actual method being used, not averages

5. **Forgetting archive access restrictions**
   - Some providers limit archive requests separately (Infura: 25K/day archive vs 75K/day standard)
   - Verify archive access is truly "unlimited" or "full"

## Scripts

### calculate_timeline.py

Calculate collection timeline given rate limits:

```bash
# RPS-based calculation
python scripts/calculate_timeline.py --blocks 13000000 --rps 5.79
# Output: 26.0 days

# Compute unit calculation
python scripts/calculate_timeline.py --blocks 13000000 --cu-per-month 300000000 --cu-per-request 20
# Output: 26.0 days (5.79 RPS sustained)
```

### test_rpc_rate_limits.py

Template for empirical rate limit testing. Copy and customize for each provider:

```python
# Key configuration
RPC_ENDPOINT = "https://eth-mainnet.g.alchemy.com/v2/YOUR_API_KEY"
REQUESTS_PER_SECOND = 5.0  # Test different rates
DELAY_BETWEEN_REQUESTS = 1.0 / REQUESTS_PER_SECOND

# Success criteria
assert success_rate >= 0.99  # 99%+ success
assert rate_limited_count == 0  # Zero 429 errors
```

## References

### rpc-comparison-template.md

Markdown template for comparison matrix and detailed analysis. Includes:
- Executive summary structure
- Provider analysis sections (pros/cons, timeline calculation)
- Comparison matrix template
- Implementation strategy template

### validated-providers.md

Real-world case study comparing Alchemy vs LlamaRPC vs Infura vs QuickNode:
- Empirical findings (1.37 RPS LlamaRPC, 5.79 RPS Alchemy)
- Timeline impact (110 days → 26 days, 4.2x speedup)
- Compute unit costs (eth_getBlockByNumber = 20 CU)
- Why Infura failed (519-day timeline due to 25K archive/day limit)

Use as reference for report structure and depth of analysis.

## Example Workflow

**User request**: "We need to collect 13M Ethereum blocks. Which RPC provider should we use?"

**Step 1 - Research**:
- Search: "Alchemy Infura QuickNode Ethereum RPC free tier comparison 2025"
- Find: Alchemy 300M CU/month, Infura 100K req/day, QuickNode 50M credits/month
- Document in comparison matrix

**Step 2 - Calculate**:
- Alchemy: 300M CU ÷ 20 CU = 15M blocks/month → 5.79 RPS → 26 days
- Infura: 25K archive/day ÷ 86,400 = 0.29 RPS → 519 days
- Create timeline comparison

**Step 3 - Validate**:
- Test Alchemy at 10 RPS, 5 RPS, 2 RPS
- Find 5 RPS works (100% success rate over 100 blocks)
- Actual sustainable: 5.79 RPS (matches calculation)

**Step 4 - Compare**:
- Alchemy: 26 days, $0, Full archive ✅ RECOMMENDED
- Infura: 519 days, $0, Limited archive ❌ REJECT

**Step 5 - Document**:
- Create report: "RPC_PROVIDER_ANALYSIS.md"
- Recommendation: Alchemy free tier with 5.0 RPS conservative limit
- Fallback: LlamaRPC at 1.37 RPS if needed
- Next steps: Create Alchemy account, test empirically

## When to Use This Skill

Invoke this skill when:

- Evaluating blockchain RPC providers for a new project
- Planning historical data backfill timelines
- Comparing free tier vs paid provider options
- Investigating rate limiting issues with current provider
- Estimating collection timelines for multi-million block datasets
- Validating archive node access for historical queries
- Researching compute unit or API credit costs
- Building POC before production implementation

## Related Patterns

This skill pairs well with:
- `blockchain-data-collection-validation` - For validating the complete data pipeline after provider selection
- Project scratch investigations in `scratch/ethereum-collector-poc/` and `scratch/rpc-provider-comparison/`
