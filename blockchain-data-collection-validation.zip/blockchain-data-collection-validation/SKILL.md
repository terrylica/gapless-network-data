---
name: blockchain-data-collection-validation
description: Empirical validation workflow for blockchain data collection pipelines before production implementation. Use when validating data sources, testing DuckDB integration, building POC collectors, or verifying complete fetch-to-storage pipelines for blockchain data.
---

# Blockchain Data Collection Validation

## Overview

This skill provides a systematic, test-driven workflow for validating blockchain data collection pipelines before production implementation. Use when building POC collectors, validating new data sources, testing DuckDB integration, or verifying complete fetch-to-storage workflows.

**Key principle**: Validate every component empirically before implementation—connectivity, schema, rate limits, storage, and complete pipeline.

## Validation Workflow

Follow this 5-step workflow to validate blockchain data collection:

### Step 1: Single Block Connectivity Test

**Purpose**: Verify basic connectivity and response format

**Create**: `01_single_block_fetch.py`

**What to validate**:
- RPC endpoint connectivity (no authentication errors)
- Response time (< 500ms acceptable)
- Block retrieval works (eth_getBlockByNumber or equivalent)
- Basic data structure returned

**Success criteria**:
- ✅ Successful block fetch
- ✅ Response time reasonable
- ✅ No connection errors

**Example output**:
```
✅ Connected to RPC endpoint
✅ Response time: 243ms
✅ Block retrieved: #21000000
```

**Next step**: If passed → Step 2 (Schema Validation)

---

### Step 2: Schema Validation

**Purpose**: Verify all required fields are present and correctly typed

**Extend**: Same script as Step 1

**What to validate**:
- All required fields present in response
- Data types match expectations (int, string, timestamp)
- Field values are reasonable (non-negative, within ranges)
- Calculated fields work (e.g., transactions_count = len(transactions))

**For Ethereum blocks, validate**:
```python
required_fields = {
    'number': int,           # block_number
    'timestamp': int,        # Unix timestamp
    'baseFeePerGas': int,    # Can be None for pre-EIP-1559
    'gasUsed': int,
    'gasLimit': int,
    'transactions': list,    # Extract len() for transactions_count
}
```

**Constraints to check**:
- `gasUsed <= gasLimit` (CHECK constraint)
- `block_number >= 0`
- `timestamp > 0`
- `transactions_count >= 0`

**Success criteria**:
- ✅ All required fields present
- ✅ Data types correct
- ✅ Values pass sanity checks
- ✅ Constraints satisfied

**Next step**: If passed → Step 3 (Rate Limit Testing)

---

### Step 3: Rate Limit Testing

**Purpose**: Find sustainable request rate without triggering 429 errors

**Create**: `02_batch_fetch.py` and `03_rate_limited_fetch.py`

**Testing progression**:

1. **Test parallel fetching** (likely to fail):
   ```python
   # 02_batch_parallel_fetch.py
   with ThreadPoolExecutor(max_workers=10) as executor:
       # Fetch blocks in parallel
   ```
   - Expected: 429 rate limit errors
   - Purpose: Understand burst limit behavior

2. **Test sequential with delays**:
   ```python
   # 03_rate_limited_fetch.py
   REQUESTS_PER_SECOND = 5.0  # Adjust based on provider
   DELAY_BETWEEN_REQUESTS = 1.0 / REQUESTS_PER_SECOND

   for block_num in range(start, end):
       block = fetch_block(block_num)
       time.sleep(DELAY_BETWEEN_REQUESTS)
   ```

**Rate testing pattern**:
- Start at documented limit (e.g., 10 RPS)
- If fails → reduce by 50% and retry
- If succeeds → try slightly higher to find limit
- Goal: 100% success rate over 50-100 blocks

**Success criteria**:
- ✅ 100% success rate (no 429 errors)
- ✅ Tested over minimum 50 blocks
- ✅ Sustainable rate documented

**Output**: Empirically validated RPS (e.g., "1.37 RPS sustainable")

**Next step**: If passed → Step 4 (Complete Pipeline)

---

### Step 4: Complete Pipeline Test (Fetch → DuckDB)

**Purpose**: Validate end-to-end data flow from RPC to DuckDB storage

**Create**: `04_complete_pipeline.py`

**What to validate**:

1. **Fetch blocks** (using validated rate limit from Step 3)
2. **Transform to DataFrame**:
   ```python
   import pandas as pd
   df = pd.DataFrame(blocks)
   ```
3. **Insert into DuckDB**:
   ```python
   from gapless_network_data.db import Database
   db = Database(db_path="./test.duckdb")
   db.initialize()
   db.insert_ethereum_blocks(df)
   ```
4. **Verify persistence**:
   ```python
   conn = db.connect()
   count = conn.execute("SELECT COUNT(*) FROM ethereum_blocks").fetchone()[0]
   assert count == len(df)
   ```

**DuckDB patterns to use** (see `references/duckdb-patterns.md`):

```python
# Batch INSERT from DataFrame
conn.execute("INSERT INTO ethereum_blocks SELECT * FROM df")

# CRITICAL: Call CHECKPOINT for durability
conn.execute("CHECKPOINT")

# Verify constraints
invalid = conn.execute("""
    SELECT COUNT(*) FROM ethereum_blocks WHERE gasUsed > gasLimit
""").fetchone()[0]
assert invalid == 0
```

**Success criteria**:
- ✅ Fetch works at validated rate
- ✅ DataFrame conversion successful
- ✅ DuckDB INSERT works
- ✅ CHECKPOINT persists data
- ✅ All CHECK constraints pass
- ✅ Data verifiable in database

**Performance benchmarks** (from empirical validation):
- Fetch: Network-bound (1-10 blocks/sec depending on RPC)
- Insert: CPU-bound (124K+ blocks/sec, far exceeds fetch rate)
- Storage: 76-100 bytes/block

**Next step**: If passed → Step 5 (Documentation)

---

### Step 5: Documentation and Decision

**Purpose**: Document findings and make go/no-go decision

**Create**: `VALIDATION_REPORT.md` (see `references/validation-report-template.md`)

**Document**:

1. **Executive Summary**
   - Provider tested
   - Sustainable rate found
   - Timeline estimate
   - Go/No-Go recommendation

2. **Test Results**
   - Each step's outcome (Pass/Fail)
   - Rate limit findings (documented vs empirical)
   - Performance metrics

3. **Pipeline Validation**
   - Fetch throughput
   - Insert performance
   - Storage estimates

4. **Decision**
   - Primary RPC provider choice
   - Conservative rate limit for production
   - Fallback strategy
   - Next steps

**Success criteria**:
- ✅ All 4 validation steps passed
- ✅ Sustainable rate documented
- ✅ Timeline calculated
- ✅ Go decision with confidence level

**Example decision**:
```
✅ GO: Alchemy validated at 5.79 RPS sustained
   Timeline: 26 days for 13M blocks
   Confidence: HIGH (100% success over 100 blocks)
   Fallback: LlamaRPC at 1.37 RPS
```

---

## DuckDB Integration Patterns

### Critical Pattern: CHECKPOINT for Durability

**Problem**: Without `CHECKPOINT`, data stays in-memory and is lost on crash.

**Solution**:
```python
# After batch INSERT
conn.execute("INSERT INTO ethereum_blocks SELECT * FROM df")

# CRITICAL: Call CHECKPOINT to persist to disk
conn.execute("CHECKPOINT")
```

**Empirically validated**: 0 data loss across 4 crash scenarios when using CHECKPOINT.

### Batch INSERT Pattern

**Use DataFrame → SQL for efficiency**:
```python
import pandas as pd

# Create DataFrame from blocks
df = pd.DataFrame(blocks)

# DuckDB can read pandas DataFrame directly
conn.execute("INSERT INTO ethereum_blocks SELECT * FROM df")
conn.execute("CHECKPOINT")
```

**Performance**: 124K blocks/sec (far exceeds any RPC rate limit)

### Schema with CHECK Constraints

**Define constraints for data quality**:
```sql
CREATE TABLE ethereum_blocks (
    block_number BIGINT PRIMARY KEY,
    timestamp TIMESTAMP NOT NULL,
    baseFeePerGas BIGINT,
    gasUsed BIGINT NOT NULL,
    gasLimit BIGINT NOT NULL,
    transactions_count INTEGER NOT NULL,
    CHECK (gasUsed <= gasLimit),
    CHECK (block_number >= 0),
    CHECK (transactions_count >= 0)
)
```

**Benefits**:
- Catches data corruption at insertion time
- No invalid data in database
- Exception-only failures (no silent errors)

### Storage Estimates

**Empirically validated** (from duckdb-batch-validation):
- 76-100 bytes/block average
- 13M Ethereum blocks: 1.0-1.2 GB
- 3.6K Bitcoin snapshots: ~5 MB

---

## Common Pitfalls to Avoid

### 1. Skipping Rate Limit Validation

**Problem**: "Provider says 50 RPS, so we'll use 50 RPS"

**Reality**: Documented limits are often burst limits, not sustained

**Example**: LlamaRPC documented 50 RPS → 1.37 RPS sustainable (2.7% of max)

**Solution**: Always test empirically over 50+ blocks minimum

### 2. Testing with Too Few Blocks

**Problem**: Test 10 blocks, all succeed → assume rate is safe

**Reality**: Sliding window rate limiting causes failures at 50+ blocks

**Example**: Parallel fetch worked for 20 blocks, failed at block 50

**Solution**: Test minimum 50 blocks, ideally 100+

### 3. Forgetting CHECKPOINT

**Problem**: Data inserted successfully, then crash → all data lost

**Reality**: DuckDB keeps data in-memory until CHECKPOINT

**Solution**: Call `conn.execute("CHECKPOINT")` after each batch

### 4. Ignoring CHECK Constraints

**Problem**: Invalid data silently inserted (gasUsed > gasLimit)

**Reality**: Corrupts downstream analysis, hard to debug

**Solution**: Define CHECK constraints in schema, verify they work

### 5. Parallel Fetching on Free Tiers

**Problem**: "3 workers is conservative"

**Reality**: Even 3 workers trigger rate limits on strict free tiers

**Example**: 3 workers worked initially, hit 429 after 50 blocks

**Solution**: Default to sequential with delays unless proven otherwise

---

## Scripts

Use the POC template scripts to validate blockchain data sources:

### Template: Single Block Fetch

See `scripts/poc_single_block.py` for complete template based on validated pattern from `scratch/ethereum-collector-poc/01_single_block_fetch.py`

```python
#!/usr/bin/env python3
"""Test 1: Single block connectivity and schema validation."""

from datetime import datetime
from web3 import Web3

RPC_ENDPOINT = "https://eth.llamarpc.com"

def test_single_block():
    w3 = Web3(Web3.HTTPProvider(RPC_ENDPOINT))
    latest = w3.eth.block_number
    block = w3.eth.get_block(latest)

    # Validate schema
    block_data = {
        'block_number': block['number'],
        'timestamp': datetime.fromtimestamp(block['timestamp']),
        'baseFeePerGas': block.get('baseFeePerGas'),
        'gasUsed': block['gasUsed'],
        'gasLimit': block['gasLimit'],
        'transactions_count': len(block['transactions']),
    }

    # Sanity checks
    assert block_data['gasUsed'] <= block_data['gasLimit']
    assert block_data['block_number'] >= 0

    print("✅ Connectivity and schema validated")
```

### Template: Complete Pipeline

See `scripts/poc_complete_pipeline.py` for full fetch → DuckDB template based on `scratch/ethereum-collector-poc/03_fetch_insert_pipeline.py`

```python
#!/usr/bin/env python3
"""Test 4: Complete fetch → DuckDB pipeline."""

import time
import pandas as pd
from web3 import Web3
from gapless_network_data.db import Database

REQUESTS_PER_SECOND = 1.37  # From Step 3 validation

def test_pipeline():
    # Fetch → Transform → Insert → Verify
    w3 = Web3(Web3.HTTPProvider(RPC_ENDPOINT))
    blocks = fetch_blocks(w3, 100)
    df = pd.DataFrame(blocks)

    db = Database(db_path="./test.duckdb")
    db.initialize()
    db.insert_ethereum_blocks(df)

    # Verify
    conn = db.connect()
    count = conn.execute("SELECT COUNT(*) FROM ethereum_blocks").fetchone()[0]
    assert count == len(df)
    print(f"✅ Pipeline validated: {count} blocks")
```

---

## References

### validation-report-template.md

Template for documenting validation findings with sections for:
- Executive summary
- Test results
- Performance metrics
- Go/No-Go decision

### duckdb-patterns.md

DuckDB integration patterns from empirical validation:
- CHECKPOINT requirement (crash-tested)
- Batch INSERT from DataFrame
- CHECK constraints for data quality
- Storage estimates (76-100 bytes/block)
- Performance benchmarks (124K blocks/sec)

Reference: `/Users/terryli/eon/gapless-network-data/scratch/duckdb-batch-validation/DUCKDB_BATCH_VALIDATION_REPORT.md `

### ethereum-collector-poc-findings.md

Complete case study of Ethereum collector POC:
- 5 test scripts progression
- Rate limit discovery (50 RPS → 1.37 RPS)
- Complete pipeline validation
- Lessons learned

Reference: `/Users/terryli/eon/gapless-network-data/scratch/ethereum-collector-poc/ETHEREUM_COLLECTOR_POC_REPORT.md `

---

## When to Use This Skill

Invoke this skill when:

- Validating a new blockchain RPC provider before implementation
- Testing DuckDB integration for blockchain data
- Building POC collector for new blockchain
- Verifying complete fetch-to-storage pipeline
- Investigating data quality issues
- Planning production collector implementation
- Need empirical validation before committing to architecture

---

## Example Workflow

**User request**: "Validate Alchemy for Ethereum data collection before implementation"

**Step 1 - Single Block**:
- Create `01_single_block_fetch.py`
- Test connectivity to Alchemy endpoint
- Validate 6-field schema
- Result: ✅ PASS (243ms response, all fields present)

**Step 2 - Schema**:
- Extend script to check all fields
- Verify data types (int, timestamp, list)
- Check constraints (gasUsed <= gasLimit)
- Result: ✅ PASS (all constraints satisfied)

**Step 3 - Rate Limits**:
- Create `02_batch_parallel_fetch.py` → ❌ FAIL (429 errors)
- Create `03_rate_limited_fetch.py` with 10 RPS → ❌ FAIL (72% success)
- Try 5 RPS → ✅ PASS (100% success over 100 blocks)
- Result: 5.79 RPS sustainable

**Step 4 - Pipeline**:
- Create `04_complete_pipeline.py`
- Fetch 100 blocks at 5 RPS
- Insert into DuckDB with CHECKPOINT
- Verify persistence and constraints
- Result: ✅ PASS (100 blocks, 8.3K blocks/sec insert)

**Step 5 - Document**:
- Create `ALCHEMY_VALIDATION_REPORT.md`
- Decision: ✅ GO with Alchemy at 5.0 RPS conservative
- Timeline: 26 days for 13M blocks
- Confidence: HIGH

---

## Related Patterns

This skill pairs well with:
- `blockchain-rpc-provider-research` - For comparing multiple providers before validation
- Project scratch investigations in `scratch/ethereum-collector-poc/` and `scratch/duckdb-batch-validation/`
